export interface ICountry {
    name: string,
    flag: string,
    latlng: Array<number>
}
